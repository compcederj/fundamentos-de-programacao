# AP1Q1

# Subprogramas


def palindrome(s):
    if len(s) <= 1:
        return True
    else:
        return s[0] == s[len(s) - 1] and palindrome(s[1:len(s) - 1])


def contemVogal(frase):
    for x in frase:
        if x in ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']:
            return True
    return False


# Programa Principal

qtdLidas = 0
qtdPalindromesLidas = 0
qtdPalindromesComVogalLidas = 0

lida = input("Digite uma string: ")
while lida != "":
    qtdLidas += 1
    if palindrome(lida):
        qtdPalindromesLidas += 1
        print(lida, "é Palíndrome")
        if contemVogal(lida):
            qtdPalindromesComVogalLidas += 1
    lida = input("Digite uma string: ")

print("Quantidade de Lidas:", qtdLidas)
print("Quantidade de Palíndromes Lidas:", qtdPalindromesLidas)
print("Quantidade de Palíndromes com Vogal(is) Lidas:", qtdPalindromesComVogalLidas)
