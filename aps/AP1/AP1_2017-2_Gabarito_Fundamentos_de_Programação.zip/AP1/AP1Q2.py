# AP1 - Questão 2

# Subprograma


def fatorial_duplo(n):
    if n == 1:
        return 1
    else:
        return fatorial_duplo(n - 2) * n


# Programa Principal
n = int(input())

while n != -1:
    if n % 2 == 1:
        r = fatorial_duplo(n)
        print("O fatorial duplo de %d é %d" % (n, r))
    else:
        print("O número %d é par" % n)

    n = int(input())
