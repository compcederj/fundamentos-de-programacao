# AP1Q3

# Subprogramas


def lerDimensoes():
    lidas = input().split()
    return int(lidas[0]), int(lidas[1])


def gerar(qLins, qCols, min, max):
    from random import randint
    vs = []
    for lin in range(qLins):
        linha = []
        for col in range(qCols):
            linha.append(randint(min, max))
        vs.append(linha)
    return vs


def mostrar(vals):
    for linha in vals:
        for x in linha:
            print(x, end=" ")
        print()
    print()
    return None


def calcularMedia(vals):
    soma = 0.0
    for linha in vals:
        for x in linha:
            soma += x
    return soma / (len(vals) * len(vals[0]))


def mostrarLinhasTodosAcima(cota, vals):
    def todosAcima(c, valsLinha):
        for x in valsLinha:
            if x <= cota:
                return False
        return True

    for linha in vals:
        if todosAcima(cota, linha):
            for x in linha:
                print(x, end=" ")
            print()
    return None


# Programa Principal

qtdLinhas, qtdColunas = lerDimensoes()

valores = gerar(qtdLinhas, qtdColunas, 0, 9)
mostrar(valores)

media = calcularMedia(valores)
print(media, "\n")

mostrarLinhasTodosAcima(media, valores)
