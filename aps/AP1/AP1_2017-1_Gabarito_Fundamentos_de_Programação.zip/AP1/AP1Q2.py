# AP1 - Questão 2

# Subprogramas


def construirEPreencher(qLins, qCols, min, max):
    from random import randint
    vals = []
    for i in range(qLins):
        novaLinha = []
        for j in range(qCols):
            novaLinha.append(randint(min, max))
        vals.append(novaLinha)
    return vals


def mostrar(vs):
    for i in range(len(vs)):
        for j in range(len(vs[i])):
            print(vs[i][j], end=' ')
        print()
    print()
    return None


def linhaMaiorSoma(vs):
    def somar(vsLin):
        total = 0
        for x in vsLin:
            total += x
        return total

    maior = somar(vs[0])
    linhaMaior = 0
    for lin in range(1, len(vs)):
        somaAtual = somar(vs[lin])
        if somaAtual > maior:
            maior = somaAtual
            linhaMaior = lin
    for x in vs[linhaMaior]:
        print(x, end=" ")
    print()
    return None


def colunaMaiorSoma(vs):
    def somarColuna(vs, col):
        total = 0
        for lin in range(len(vs)):
            total += vs[lin][col]
        return total


    maior = somarColuna(vs, 0)
    colunaMaior = 0
    for col in range(1, len(vs[0])):
        atual = somarColuna(vs, col)
        if atual > maior:
            maior = atual
            colunaMaior = col
    for linha in range(len(vs)):
        print(vs[linha][colunaMaior])
    return None


# Programa Principal
dimensoes = input().split()
qtdLinhas = int(dimensoes[0])
qtdColunas = int(dimensoes[1])
valores = construirEPreencher(qtdLinhas, qtdColunas, 10, 99)
mostrar(valores)
linhaMaiorSoma(valores)
print()
colunaMaiorSoma(valores)
print()