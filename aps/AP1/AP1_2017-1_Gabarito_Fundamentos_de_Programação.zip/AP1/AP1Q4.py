# AP1 - Questão 4

# Subprogramas


def lerVetor():
    n = int(input())
    vetor = []
    for i in range(n):
        vetor.append(input())
    return vetor


def lerValor():
    return input()


def buscaBinaria(lista, valor):
    inicio = 0
    fim = len(lista) - 1
    meio = (inicio + fim) // 2
    while inicio < fim and valor != lista[meio]:
        if valor > lista[meio]:
            inicio = meio + 1
        else:
            fim = meio - 1
        meio = (inicio + fim) // 2
    if valor != lista[meio]:
        return -1
    else:
        return meio


# Programa Principal
colecao = lerVetor()
nome = lerValor()
pos = buscaBinaria(colecao, nome)
if pos == -1:
    print("Valor não encontrado")
else:
    print("O valor foi encontrado na posição", pos)