# AP1 - Questão 1

# Programa Principal
lido = int(input())
qtdLidos = 0
oMaior = lido
segundoMaior = -1
while lido >= 0:
    qtdLidos += 1
    if lido > oMaior:
        segundoMaior = oMaior
        oMaior = lido
    elif qtdLidos > 1 and lido > segundoMaior:
        segundoMaior = lido
    lido = int(input())
if qtdLidos == 0:
    print("Nenhum valor válido!!!")
elif qtdLidos == 1:
    print("Apenas um valor foi lido:", oMaior)
else:
    print("Os dois maiores números lidos foram:", oMaior, "e", segundoMaior)