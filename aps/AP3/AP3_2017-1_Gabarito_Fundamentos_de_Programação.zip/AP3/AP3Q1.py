# AP3 - Questão 1

# Subprograma


def primo(n):
    if n < 2:
        return False
    limite = n/2
    i = 2
    while i <= limite and n%i != 0:
        i += 1
    return i > limite


# Programa Principal
par = input().split()
menor = int(par[0])
maior = int(par[1])
for num in range(menor, maior+1):
    if primo(num):
        print(num)
