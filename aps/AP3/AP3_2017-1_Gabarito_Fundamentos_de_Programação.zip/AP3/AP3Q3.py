# AP3 - Questão 3

import struct

# Programa Principal
with open("entrada1.bin", "rb") as entrada1:
    with open("entrada2.bin", "rb") as entrada2:
        with open("saida.bin", "wb") as saida:
            n1 = struct.unpack("i", entrada1.read(4))[0]
            n2 = struct.unpack("i", entrada2.read(4))[0]
            saida.write(struct.pack("i", n1 + n2))

            if n1 > 0:
                atual1 = struct.unpack("i", entrada1.read(4))[0]

            if n2 > 0:
                atual2 = struct.unpack("i", entrada2.read(4))[0]

            while n1 > 0 and n2 > 0:
                if atual1 <= atual2:
                    saida.write(struct.pack("i", atual1))
                    n1 -= 1
                    if n1 > 0:
                        atual1 = struct.unpack("i", entrada1.read(4))[0]
                elif atual2 < atual1:
                    saida.write(struct.pack("i", atual2))
                    n2 -= 1
                    if n2 > 0:
                        atual2 = struct.unpack("i", entrada2.read(4))[0]

            if n1 > 0:
                saida.write(struct.pack("i", atual1))
                while n1 > 0:
                    saida.write(entrada1.read(4))
                    n1 -= 1

            if n2 > 0:
                saida.write(struct.pack("i", atual2))
                while n2 > 0:
                    saida.write(entrada2.read(4))
                    n2 -= 1
