# AP3 - Questão 2

# Subprogramas


def comb(n, k):
    if k == 1:
        return n
    if k == n:
        return 1
    return comb(n-1, k-1) + comb(n-1, k)


# Programa Principal
par = input().split()
print(comb(int(par[0]), int(par[1])))