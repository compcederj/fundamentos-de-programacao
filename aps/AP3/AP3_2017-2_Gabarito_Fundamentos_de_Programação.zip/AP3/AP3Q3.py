# AP3 - Questão 3


# Subprogramas
def conjPalavrasLidas():
    palavras = set()
    palavra = input()
    while palavra!="fim":
        palavras.add(palavra)
        palavra = input()
    return palavras


def palavrasComOcorrencias(nArq, conjPals):
    dicioNoConj = dict()
    arq = open(nArq,"r")
    for linha in arq:
        palavras = linha.strip().split()
        for pal in palavras:
            if pal in conjPals:
                if dicioNoConj.get(pal)==None:
                    dicioNoConj[pal] = 1
                else:
                    dicioNoConj[pal] += 1
    arq.close()
    return dicioNoConj


def mostrarOrdenado(dPals):
    for pal,num in sorted(dPals.items()):
        print(pal, "ocorreu", num, "vez(es)")
    print()


# Programa Principal
conjuntoPals = conjPalavrasLidas()
nomeArq = input()
print(conjuntoPals)
dicPalsComContagem = palavrasComOcorrencias(nomeArq, conjuntoPals)
mostrarOrdenado(dicPalsComContagem)