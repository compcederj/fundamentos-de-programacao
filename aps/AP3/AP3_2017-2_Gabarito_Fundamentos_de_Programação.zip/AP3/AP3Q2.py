# AP3 - Questão 2


# Subprogramas
def processa(nArq):
    vogais = "AEIOU"
    consoantes = "BCDFGHJKLMNPQRSTVWXYZ"
    digitos = "0123456789"
    qtdVogais = 0
    qtdConsoantes = 0
    qtdDigitos = 0
    arq = open(nArq, "r")
    for linha in arq:
        for c in linha:
            if c.upper() in vogais:
                qtdVogais += 1
            elif c.upper() in consoantes:
                qtdConsoantes += 1
            elif c in digitos:
                qtdDigitos += 1
    arq.close()
    print("Quantidade de vogais em", nArq, ":", qtdVogais)
    print("Quantidade de consoantes em", nArq, ":", qtdConsoantes)
    print("Quantidade de dígitos em", nArq, ":", qtdDigitos)
    print()


# Programa Principal
nomes = []

nomeArq = input()
while nomeArq != "":
    nomes.append(nomeArq)
    nomeArq = input()

for nomeArq in nomes:
    processa(nomeArq)