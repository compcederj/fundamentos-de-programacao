# AP2 - Questão 1


# Subprogramas

def distancia(pt1, pt2):
    return ((pt1[0]-pt2[0])**2+(pt1[1]-pt2[1])**2)**0.5


def pontoDeMaiorDistancia(pt, nomeArq):
    distanciaMaior = 0
    ptMaisDistante = pt
    bd = open(nomeArq,"r")
    for linha in bd:
        p = linha.split()
        atual = (int(p[0]),int(p[1]))
        dist = distancia(pt,atual)
        if dist>distanciaMaior:
            distanciaMaior = dist
            ptMaisDistante = atual
    bd.close()
    return ptMaisDistante, distanciaMaior

# Programa Principal
nome = input("Diga o nome do arquivo de pontos: ")
arqPontos = open(nome, "r")
linha = arqPontos.readline()
if linha=="":
    print("Arquivo vazio!!!")
else:
    ponto = linha.split()
    origem = (int(ponto[0]),int(ponto[1]))
    destino, maiorDistancia = pontoDeMaiorDistancia(origem,nome)
    for linha in arqPontos:
        ponto = linha.split()
        novaOrigem = (int(ponto[0]),int(ponto[1]))
        novoDestino, novaMaiorDistancia = pontoDeMaiorDistancia(novaOrigem,nome)
        if novaMaiorDistancia>maiorDistancia:
            maiorDistancia = novaMaiorDistancia
            origem = novaOrigem
            destino = novoDestino
    print("Pontos mais distantes:",origem, "e",destino, "com distância =","%.2f"%maiorDistancia)
arqPontos.close()
