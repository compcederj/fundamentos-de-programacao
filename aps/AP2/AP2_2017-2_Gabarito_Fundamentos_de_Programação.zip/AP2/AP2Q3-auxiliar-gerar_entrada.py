# AP2 - Questão 3 - Programa auxiliar para gerar arquivos de entrada (apenas para ilustrar)

import struct

dados = [5.5, 9.0, 5.4, 7.2, 1.0, 3.5]

with open("entrada.bin", "wb") as entrada:
    bloco = struct.pack("=i", len(dados))
    entrada.write(bloco)

    for valor in dados:
        bloco = struct.pack("=d", valor)
        entrada.write(bloco)
