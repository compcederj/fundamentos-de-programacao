# AP2 - Questão 3 - Programa auxiliar para exibir os arquivos gerados (apenas para ilustrar)


def ler_valores(nome):
    import struct
    resultado = []
    with open(nome, "rb") as arq_entrada:
        n = struct.unpack("=i", arq_entrada.read(4))[0]
        for i in range(n):
            resultado.append(struct.unpack("=d", arq_entrada.read(8))[0])
    return resultado


print(ler_valores("menores.bin"))
print(ler_valores("maiores.bin"))
