# AP2 - Questão 3


# Subprogramas

def ler_valores():
    import struct
    resultado = []
    with open("entrada.bin", "rb") as arq_entrada:
        n = struct.unpack("=i", arq_entrada.read(4))[0]
        for i in range(n):
            resultado.append(struct.unpack("=d", arq_entrada.read(8))[0])
    return resultado


def calcular_media(lista):
    soma = 0
    for v in lista:
        soma += v
    return soma / len(lista)


def separar_valores(lista, limiar):
    resultado_menores = []
    resultado_maiores = []
    for v in lista:
        if v <= limiar:
            resultado_menores.append(v)
        else:
            resultado_maiores.append(v)
    return resultado_menores, resultado_maiores


def escrever_saida(lista, nome):
    import struct
    with open(nome, "wb") as arq:
        arq.write(struct.pack("=i", len(lista)))
        for v in lista:
            arq.write(struct.pack("=d", v))


# Programa Principal
valores = ler_valores()
media = calcular_media(valores)
menores, maiores = separar_valores(valores, media)
escrever_saida(menores, "menores.bin")
escrever_saida(maiores, "maiores.bin")
