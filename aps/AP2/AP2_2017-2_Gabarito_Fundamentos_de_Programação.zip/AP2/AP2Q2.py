# AP2 - Questão 2

# Programa Principal

mensagens = dict()
with open("mensagens.txt", "r") as arq_mensagens:
    idioma = arq_mensagens.readline().strip()  # A ausência de .strip() não foi descontada
    while idioma != "":
        mensagens[idioma] = arq_mensagens.readline().strip()  # A ausência de .strip() não foi descontada
        idioma = arq_mensagens.readline().strip()  # A ausência de .strip() não foi descontada

with open("clientes.txt", "r") as arq_clientes:
    nome = arq_clientes.readline().strip()  # A ausência de .strip() não foi descontada
    while nome != "":
        idioma = arq_clientes.readline().strip()  # A ausência de .strip() não foi descontada

        print(nome)
        print(mensagens[idioma])
        print()

        nome = arq_clientes.readline().strip()  # A ausência de .strip() não foi descontada
