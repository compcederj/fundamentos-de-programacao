# AP2 - Questão 3

# Subprogramas


def lerLista():
    import struct
    with open("entrada.bin", "rb") as arq:
        n = struct.unpack("i", arq.read(4))[0]
        valores = []
        for i in range(n):
            valores.append(struct.unpack("d", arq.read(8))[0])
    return valores


def ordenarLista(lista):
    for i in range(0, len(lista)):
        menor = i
        for k in range(i, len(lista)):
            if lista[k] < lista[menor]:
                menor = k
        lista[menor], lista[i] = lista[i], lista[menor]
    return valores


def escreverLista(lista):
    import struct
    with open("saida.bin", "wb") as arq:
        arq.write(struct.pack("i", len(lista)))
        for v in lista:
            arq.write(struct.pack("d", v))
    return None


# Programa Principal
valores = lerLista()
valores = ordenarLista(valores)
escreverLista(valores)