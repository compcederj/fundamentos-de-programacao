# AP2 - Questão 2

# Subprogramas


def processa(nomeArq):
    pares = dict()
    arquivo = open(nomeArq, "r")
    for linha in arquivo:
        palavras = linha.strip().split()
        for pal in palavras:
            if pal[0] in {'a', 'e', 'i', 'o', 'u'}:
                if pares.get(pal) == None:
                    pares[pal] = 1
                else:
                    pares[pal] += 1
    arquivo.close()
    return pares


# Programa Principal

nome = input("Nome do Arquivo: ")
dicionario = processa(nome)
print(dicionario)
