# AP2 - Questão 1

# Subprograma


def inserir(nomeArq, posLinha, novaLinha):
    arq = open(nomeArq, "r")
    arqAuxiliar = open(nomeArq+"$$$", "w")
    qtdLinhas = 0
    for linha in arq:
        qtdLinhas += 1
        if qtdLinhas == posLinha:
            arqAuxiliar.write(novaLinha+"\n")
        arqAuxiliar.write(linha)
    if qtdLinhas < posLinha:
        for i in range(qtdLinhas, posLinha-1):
            arqAuxiliar.write("\n")
        arqAuxiliar.write(novaLinha+"\n")
    arq.close()
    arqAuxiliar.close()

    arq = open(nomeArq, "w")
    arqAuxiliar = open(nomeArq+"$$$", "r")
    for linha in arqAuxiliar:
        arq.write(linha)
    arq.close()
    arqAuxiliar.close()

    return None