# AD1 - Questão 3


# Subprogramas
def ajuste(original, ncol, nlin, deltax, deltay):
    ajustada = [None] * nlin
    for lin in range(nlin):
        ajustada[lin] = [None] * ncol
        j = (((lin - deltay) % nlin) + nlin) % nlin
        for col in range(ncol):
            i = (((col - deltax) % ncol) + ncol) % ncol
            ajustada[lin][col] = original[j][i]
    return ajustada


def imprime(imagem, ncol, nlin):
    for lin in range(nlin):
        for col in range(ncol):
            print(imagem[lin][col], end=' ')
        print()


# Programa principal
strs = input().split()
c = int(strs[0])
l = int(strs[1])

img = [None] * l
for y in range(l):
    img[y] = input().split()

x = y = -1
somax = somay = 0
while x != 0 or y != 0:
    strs = input().split()
    x = int(strs[0])
    y = int(strs[1])
    somax += x
    somay += y

img = ajuste(img, c, l, somax, somay)
imprime(img, c, l)
