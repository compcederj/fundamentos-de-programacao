# AD1 - Questão 6


# Subprogramas
def gerar(qL, qC):
    from random import randint
    vals = []
    for lin in range(qL):
        linha = []
        for col in range(qC):
            linha.append(randint(0, 9))
        vals.append(linha)
    return vals


def mostrar(vals):
    for lin in vals:
        for x in lin:
            print(x, end=" ")
        print()
    return None


def mostrarDiagonais(vals):
    qLins = len(vals)
    qCols = len(vals[0])
    for diagonal in range(qLins + qCols - 1):
        for lin in range(qLins - 1, -1, -1):
            for col in range(qCols):
                if diagonal == lin + col:
                    print(vals[lin][col], end=" ")
        print()
    for diagonal in range(qLins - 1, -qCols, -1):
        for lin in range(qLins):
            for col in range(qCols):
                if diagonal == lin - col:
                    print(vals[lin][col], end=" ")
        print()
    return None


# Programa Principal
qtdLinhas = int(input("Digite a quantidade de linhas: "))
qtdColunas = int(input("Digite a quantidade de colunas: "))

valores = gerar(qtdLinhas, qtdColunas)

print()
print("Matriz Gerada Aleatoriamente:")
mostrar(valores)

print()
print("Listagem das Diagonais:")
mostrarDiagonais(valores)