# AD1 - Questão 5


# Subprogramas
def mascara(d):
    if 0 <= d < 10:
        return str(d)
    elif d == 10:
        return "A"
    elif d == 11:
        return "B"
    elif d == 12:
        return "C"
    elif d == 13:
        return "D"
    elif d == 14:
        return "E"
    elif d == 15:
        return "F"
    else:
        return None


def converte(dec, b):
    if dec < b:
        return mascara(dec)
    else:
        return converte(dec // b, b) + mascara(dec % b)


# Programa Principal
numDecimalLido = int(input("Digite um valor inteiro não negativo (negativo para sair): "))
while numDecimalLido >= 0:
    print("Resultado das Conversões:")
    for base in range(2, 17):
        print("Base", str(base) + ":", converte(numDecimalLido, base))
    print()
    numDecimalLido = int(input("Digite um valor inteiro não negativo (negativo para sair): "))