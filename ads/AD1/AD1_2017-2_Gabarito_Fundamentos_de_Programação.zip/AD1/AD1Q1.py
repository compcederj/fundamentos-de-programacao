# AD1 - Questão 1


# Programa principal
strs = input().split()
n = int(strs[0])
p = int(strs[1])
k = 1

while n != 0 or p != 0:
    nomes = [None] * n
    for i in range(n):
        nomes[i] = input()

    print('Sequência %d' % k)
    for j in range(p):
        strs = input().split()
        soma = 0
        for i in range(n):
            soma += int(strs[i])
        print(nomes[soma % n])
    print()

    strs = input().split()
    n = int(strs[0])
    p = int(strs[1])
    k += 1
