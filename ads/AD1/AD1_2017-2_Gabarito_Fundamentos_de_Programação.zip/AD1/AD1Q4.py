# AD1 - Questão 4


# Subprogramas
def gerarDNA(tam):
    from random import randint
    opcoes = "ACGT"
    sequencia = ""
    for i in range(tam):
        sequencia += opcoes[randint(0, len(opcoes) - 1)]
    return sequencia


def contar(sV, d):
    total = 0
    for inicio in range(len(sV) - len(d) + 1):
        if d == sV[inicio:inicio + len(d)]:
            total += 1
    return total


def complementarInvertido(dNA):
    sequencia = ""
    for x in dNA:
        if x == "A":
            complementar = "C"
        elif x == "C":
            complementar = "A"
        elif x == "G":
            complementar = "T"
        else:
            complementar = "G"
        sequencia = complementar + sequencia
    return sequencia


# Programa Principal
tamanhoSerVivo = int(input("Comprimento da DNA do ser vivo: "))
serVivo = gerarDNA(tamanhoSerVivo)
print("DNA do ser vivo gerado aleatoriamente:", serVivo)
tamanhoDoenca = int(input("Comprimento da DNA da doença: "))
doenca = gerarDNA(tamanhoDoenca)
print("DNA da doença gerada aleatoriamente:", doenca)
print("Contagem das ocorrências direta da doença no ser vivo:", contar(serVivo, doenca))
print("DNA do ser vivo, complementar invertido:", complementarInvertido(serVivo))
print("Contagem das ocorrências da doença na DNA complementar invertida:",
      contar(complementarInvertido(serVivo), doenca))