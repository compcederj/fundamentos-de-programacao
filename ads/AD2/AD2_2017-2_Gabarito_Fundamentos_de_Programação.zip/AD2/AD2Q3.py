# AD2 - Questão 3


# Subprogramas

def atualizar_time(times, nome_time, gols_marcados, gols_sofridos):
    dados_time = times[nome_time]
    if gols_marcados > gols_sofridos:
        dados_time[1] = 3                           # pontos (vitória)
    elif gols_marcados == gols_sofridos:
        dados_time[1] = 1                           # pontos (empate)
    dados_time[2] += 1                              # jogos_disputados
    dados_time[3] += gols_marcados                  # gols_marcados
    dados_time[4] += gols_sofridos                  # gols_sofridos
    dados_time[5] += gols_marcados - gols_sofridos  # saldo


def time1_antecede_time2(dados_time1, dados_time2):
    if dados_time1[1] > dados_time2[1]:  # pontos
        return True
    elif dados_time1[1] == dados_time2[1]:
        if dados_time1[5] > dados_time2[5]:  # saldo
            return True
        elif dados_time1[5] == dados_time2[5]:
            if dados_time1[3] > dados_time2[3]:  # gols_marcados
                return True
            elif dados_time1[3] == dados_time2[3]:
                return dados_time1[0] < dados_time2[0]  # nome
    return False


def ordenar(times):
    for i in range(1, len(times)):
        atual = times[i]
        k = i
        while k > 0 and time1_antecede_time2(atual, times[k - 1]):
            times[k] = times[k - 1]
            k -= 1
        times[k] = atual


def empatou(dados_time1, dados_time2):
    return dados_time1[1] == dados_time2[1] and dados_time1[3] == dados_time2[3] and dados_time1[5] == dados_time2[5]


def imprimir_linha(posicao_time, dados_time):
    saida.write("%2d %20s %2d %2d %2d %2d %3d\n" % (
                posicao_time,    # posicao_time
                dados_time[0],   # nome
                dados_time[1],   # pontos
                dados_time[2],   # jogos_disputados
                dados_time[3],   # gols_marcados
                dados_time[4],   # gols_sofridos
                dados_time[5]))  # saldo


# Programa principal

with open("partidas.txt", "r") as entrada:
    t, j = map(int, entrada.readline().split())

    dados = dict()
    for ind in range(t):
        nome = entrada.readline().strip()
        dados[nome] = [nome, 0, 0, 0, 0, 0]  # [nome, pontos, jogos_disputados, gols_marcados, gols_sofridos, saldo]

    for ind in range(j):
        nome1, gols1, x, gols2, nome2 = entrada.readline().split()
        atualizar_time(dados, nome1, int(gols1), int(gols2))
        atualizar_time(dados, nome2, int(gols2), int(gols1))

lista = list(dados.values())
ordenar(lista)

with open("tabela.txt", "w") as saida:
    posicao = 1
    imprimir_linha(posicao, lista[0])
    for ind in range(1, t):
        if not empatou(lista[ind], lista[ind - 1]):
            posicao += 1
        imprimir_linha(posicao, lista[ind])
