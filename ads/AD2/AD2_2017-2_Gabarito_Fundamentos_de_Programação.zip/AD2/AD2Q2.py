# AD2 - Questão 2


# Subprograma
def distancia(xA, yA, xB, yB):
    return ((xA - xB) ** 2 + (yA - yB) ** 2) ** 0.5


# Programa Principal
xCidadao, yCidadao = input().split()
xCidadao, yCidadao = int(xCidadao), int(yCidadao)

bd = open("farmacias.txt")
linha = bd.readline()
if bd == "":
    print("Arquivo de Farmácias está vazio!!!")
else:
    xFarmaciaMaisProxima, yFarmaciaMaisProxima = linha.split()
    xFarmaciaMaisProxima, yFarmaciaMaisProxima = int(xFarmaciaMaisProxima), int(yFarmaciaMaisProxima)
    menorDistancia = distancia(xFarmaciaMaisProxima, yFarmaciaMaisProxima, xCidadao, yCidadao)
    for posFarmacia in bd:
        xFarmacia, yFarmacia = posFarmacia.split()
        xFarmacia, yFarmacia = int(xFarmacia), int(yFarmacia)
        distAtual = distancia(xFarmacia, yFarmacia, xCidadao, yCidadao)
        if distAtual < menorDistancia:
            menorDistancia = distAtual
            xFarmaciaMaisProxima, yFarmaciaMaisProxima = xFarmacia, yFarmacia

    print("Local da Farmácia Mais Próxima:",xFarmaciaMaisProxima, yFarmaciaMaisProxima)

    print("Distância à Percorrer:", menorDistancia)

bd.close()