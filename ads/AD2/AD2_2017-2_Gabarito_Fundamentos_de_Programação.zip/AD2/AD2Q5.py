# AD2 - Questão 5


# Subprogramas

def diferencas(str1, str2):
    c = 0
    l = min(len(str1), len(str2))
    for i in range(l):
        if str1[i] != str2[i]:
            c += 1
    return c + (len(str1) - l) + (len(str2) - l)


# Programa principal

with open("listas_de_presenca.txt", "r") as entrada:
    with open("quantidade_de_falsificacoes.txt", "w") as saida:
        disciplina = entrada.readline().strip()

        while disciplina != "Fim":
            n = int(entrada.readline())

            alunos = dict()
            for i in range(n):
                nome, assinatura = entrada.readline().split()
                alunos[nome] = assinatura

            contador = 0

            m = int(entrada.readline())
            for i in range(m):
                nome, assinatura = entrada.readline().split()
                if diferencas(alunos[nome], assinatura) > 1:
                    contador += 1

            saida.write("%s: %d\n" % (disciplina, contador))

            disciplina = entrada.readline().strip()
