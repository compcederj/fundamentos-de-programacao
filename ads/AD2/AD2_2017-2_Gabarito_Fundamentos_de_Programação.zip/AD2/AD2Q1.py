# AD2 - Questão 1


# Subprogramas
def lerPolinomio():
    coeficientes = input().split()
    for i in range(len(coeficientes)):
        coeficientes[i] = float(coeficientes[i])
    return coeficientes


def somar(a, b):
    if len(a) >= len(b):
        c = [0.0] * len(a)
        DIFGRAU = len(a) - len(b)
        for i in range(len(a)):
            if i < DIFGRAU:
                c[i] = a[i]
            else:
                c[i] = a[i] + b[i - DIFGRAU]
    else:
        c = [0.0] * len(b)
        DIFGRAU = len(b) - len(a)
        for i in range(len(b)):
            if i < DIFGRAU:
                c[i] = b[i]
            else:
                c[i] = a[i - DIFGRAU] + b[i]
    return c


def multiplicar(a, b):
    GRAU = (len(a) + len(b) - 1)
    c = [0.0] * GRAU
    for i in range(len(a)):
        for j in range(len(b)):
            c[i + j] += a[i] * b[j]
    return c


def mostrar(a):
    for x in a:
        print(x, end=" ")
    print()
    return None


# Programa Principal
p = lerPolinomio()
q = lerPolinomio()

soma = somar(p, q)
multiplicacao = multiplicar(p, q)

mostrar(soma)
mostrar(multiplicacao)
