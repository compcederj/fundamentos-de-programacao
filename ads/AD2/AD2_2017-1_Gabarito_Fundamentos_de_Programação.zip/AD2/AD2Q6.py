# AD2 - Questão 6

import struct

with open("entrada.bin", "rb") as arq, open("saida_inteiros.bin", "wb") as arqi, open("saida_reais.bin", "wb") as arqd:
    n = struct.unpack("=i", arq.read(4))[0]
    arqi.write(struct.pack("=i", n))
    arqd.write(struct.pack("=i", n))
    for i in range(n):
        par = struct.unpack("=id", arq.read(4 + 8))
        arqi.write(struct.pack("=i", par[0]))
        arqd.write(struct.pack("=d", par[1]))
