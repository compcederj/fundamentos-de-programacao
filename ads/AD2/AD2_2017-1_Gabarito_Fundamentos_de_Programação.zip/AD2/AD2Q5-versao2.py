# AD2 - Questão 5 (versão 1 - eficiente)

# Subprogramas


def lerMatriz():
    matriz = dict()
    par = input().split(" ")
    linhas = int(par[0])
    colunas = int(par[1])
    for i in range(linhas):
        valores = input().split(" ")
        for j in range(colunas):
            valor = int(valores[j])
            if valor != 0:
                matriz[(i, j)] = valor
    return matriz


def imprimirMatriz(matriz, nome):
    print("Matriz esparsa", nome)
    print(matriz)
    print()


# Programa Principal
A = lerMatriz()
B = lerMatriz()

R = dict()
for (i,k1), aik in A.items():
    for (k2, j), bkj in B.items():
        if k1 == k2:
            if R.get((i, j)) is not None:
                R[(i, j)] += aik * bkj
            else:
                R[(i, j)] = aik * bkj

imprimirMatriz(A, "A")
imprimirMatriz(B, "B")
imprimirMatriz(R, "R")  # Pode ser que alguns coeficientes de R sejam iguais a zero.
