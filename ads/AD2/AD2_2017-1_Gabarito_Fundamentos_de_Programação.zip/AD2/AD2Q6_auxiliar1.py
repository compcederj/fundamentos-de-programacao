# AD2 - Questão 6 - Programa auxiliar para criar arquivos binários no formato especificado

import struct

with open("entrada.bin", "wb") as arq:
    n = int(input("Informe a quantidade desejada de registros: "))
    arq.write(struct.pack("=i", n))
    for i in range(n):
        v = int(input("Informe o número inteiro %d/%d: " % ((i + 1), n)))
        arq.write(struct.pack("=i", v))
        v = float(input("Informe o número real %d/%d: " % ((i + 1), n)))
        arq.write(struct.pack("=d", v))
