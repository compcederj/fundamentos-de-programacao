# AD2 - Questão 2

nomeArq = input("Nome do Arquivo: ")
arq = open(nomeArq, "r")

linha = arq.readline() #Pega a primeira linha do arquivo

if linha == "": # se linha vazia
    print("Arquivo vazio")
else:
    # possui pelo menos uma linha com 1 ou mais números
    partes = linha.split()

    # inicializa variáveis maior, soma e qtdNumeros
    maior = float(partes[0])
    soma = maior
    qtdNumeros = 1

    # processa todos os demais números da primeira linha
    for i in range(1, len(partes)):
        numero = float(partes[i])
        soma += numero
        qtdNumeros += 1
        if numero>maior:
            maior = numero

    # Pega a segunda linha
    linha = arq.readline()

    while linha!="":
        # Processa a linha atual
        partes = linha.split()
        for i in range(0,len(partes)):
            numero = float(partes[i]) #Converte para float
            qtdNumeros += 1
            soma += numero
            if numero>maior:
                maior = numero

        # Pega a próxima linha
        linha = arq.readline()

    print("Maior =", "%0.2f"%(maior))
    print("Média =", "%0.2f"%(soma/qtdNumeros))

arq.close()
