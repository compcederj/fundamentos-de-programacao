# AD2 - Questão 3

# Subprogramas


def achaNome(ag, tel):
    for nome, telefone in ag.items():
        if tel == telefone:
            return nome
    return None


def mostrarOrdenadoPorNomeOuTelefone(ag, modo):
    if modo:  # pelo nome
        chavesOrdenadasPorNome = sorted(ag.keys())
        for nome in chavesOrdenadasPorNome:
            print(nome, ag[nome])
    else:  # pelo telefone
        valoresOrdenadosPorFone = sorted(ag.values())
        for fone in valoresOrdenadosPorFone:
            nome = achaNome(ag, fone)
            print(nome, fone)
    return None


# Programa Principal
agenda = dict()
partes = input("Nome e telefone (00)0000-0000: ").split()

while partes[0] != "acabou":
    agenda[partes[0]] = partes[1]
    partes = input("Nome e telefone (00)0000-0000: ").split()

mostrarOrdenadoPorNomeOuTelefone(agenda, True)
print()
mostrarOrdenadoPorNomeOuTelefone(agenda, False)
