# AD2 - Questão 6 - Programa auxiliar para mostrar arquivos binários no formato especificado

import struct

with open("entrada.bin", "rb") as arq:
    n = struct.unpack("=i", arq.read(4))[0]
    print(n)
    for i in range(n):
        print(struct.unpack("=id", arq.read(4+8)))
    print()

with open("saida_inteiros.bin", "rb") as arq:
    n = struct.unpack("=i", arq.read(4))[0]
    print(n)
    for i in range(n):
        print(struct.unpack("=i", arq.read(4))[0])
    print()

with open("saida_reais.bin", "rb") as arq:
    n = struct.unpack("=i", arq.read(4))[0]
    print(n)
    for i in range(n):
        print(struct.unpack("=d", arq.read(8))[0])
    print()
