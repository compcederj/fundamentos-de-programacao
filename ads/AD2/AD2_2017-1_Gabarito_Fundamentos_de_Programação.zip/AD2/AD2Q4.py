# AD2 - Questão 4

# Subprogramas


def lerHashtags():
    lista = []
    with open("hashtags.txt", "r") as arq:
        n = int(arq.readline())
        for i in range(n):
            lista.append(arq.readline())
    return lista


def atualizaModas(modas, frequenciaModas, atual, frequenciaAtual):
    if frequenciaModas == frequenciaAtual:
        modas.append(atual) # A hashtag atual tema mesma moda das hashtags selecionadas até o momento
    elif frequenciaModas < frequenciaAtual:
        modas = [atual] # A hashtag atual é mais frequente, logo é a nova moda
        frequenciaModas = frequenciaAtual
    return modas, frequenciaModas


def encontrarTrendtopics(listaOrdenada):
    modas = []
    frequenciaModas = 0
    atual = listaOrdenada[0]
    inicioAtual = 0
    for ind in range(1, len(listaOrdenada)):
        if listaOrdenada[ind] != atual:
            frequenciaAtual = ind - inicioAtual
            modas, frequenciaModas = atualizaModas(modas, frequenciaModas, atual, frequenciaAtual)
            atual = hashtags[ind]
            inicioAtual = ind
    frequenciaAtual = len(listaOrdenada) - inicioAtual
    modas, frequenciaModas = atualizaModas(modas, frequenciaModas, atual, frequenciaAtual)
    return modas


def escreverTrendtopics(lista):
    with open("trendtopics.txt", "w") as arq:
        for hashtag in lista:
            arq.write(hashtag)
    return None


# Programa principal
hashtags = lerHashtags()
hashtags.sort()
trendtopics = encontrarTrendtopics(hashtags)
escreverTrendtopics(trendtopics)
