# AD2 - Questão 5 (versão 1 - ineficiente)

# Subprogramas


def lerMatriz():
    matriz = dict()
    par = input().split(" ")
    linhas = int(par[0])
    colunas = int(par[1])
    for i in range(linhas):
        valores = input().split(" ")
        for j in range(colunas):
            valor = int(valores[j])
            if valor != 0:
                matriz[(i, j)] = valor
    return matriz, linhas, colunas


def imprimirMatriz(matriz, nome):
    print("Matriz esparsa", nome)
    print(matriz)
    print()


# Programa Principal
A, M, T = lerMatriz()
B, T, N = lerMatriz()

R = dict()
for i in range(M):
    for j in range(N):
        valor = 0
        for k in range(T):
            aik = A.get((i, k))
            bkj = B.get((k, j))
            if aik is not None and bkj is not None:
                valor += aik * bkj
        if valor != 0:
            R[(i, j)] = valor

imprimirMatriz(A, "A")
imprimirMatriz(B, "B")
imprimirMatriz(R, "R")
